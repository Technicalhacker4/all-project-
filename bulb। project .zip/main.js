console.log('Hello World!');
function on(){
  let bulb = document.getElementById('img')
  .style.innerHTML = img.src= '/img/images__5_-removebg-preview (1).png' ;
  
}
function off(){
  let off = document.getElementById('img').style.innerHTML = img.src ='/img/images__3_-removebg-preview.png';
}
