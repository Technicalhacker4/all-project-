console.log('Hello World!');
function myFunction(x){
  x.classList.toggle('change');
nav = document.getElementById('nav').style.visibility = 'visible';
}
