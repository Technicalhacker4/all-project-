console.log('Hello World!');
var second = 00;
var tens = 00;
var appendSeconds = document.getElementById('second');
var appendtens = document.getElementById('tens');
var buttonStart = document.getElementById('button-Start');
  var buttonStop = document.getElementById('button-stop');
  var buttonReset = document.getElementById('button-rest');
  var Interval ;
buttonStart.onclick = function() {
    
    clearInterval(Interval);
     Interval = setInterval(startTimer, 10);
  }
      buttonStop.onclick = function() {
       clearInterval(Interval);
  }
  

  buttonReset.onclick = function() {
     clearInterval(Interval);
    tens = "00";
  	second = "00";
    appendtens.innerHTML = tens;
  	appendSeconds.innerHTML = second;
  }


function startTimer () {
    tens++; 
    
    if(tens <= 9){
      appendtens.innerHTML = "0" + tens;
    }
    
    if (tens > 9){
      appendtens.innerHTML = tens;
      
    } 
    
    if (tens > 99) {
      console.log("seconds");
      second++;
      appendSeconds.innerHTML = "0" + second;
      tens = 0;
      appendtens.innerHTML = "0" + 0;
    }
    
    if (second > 9){
      appendSeconds.innerHTML = seconds;
    }
  
  }
  










/*window.onload = function () {
  
  var seconds = 00; 
  var tens = 00; 
  var appendTens = document.getElementById("tens");
  var appendSeconds = document.getElementById("second");
  var buttonStart = document.getElementById''('button-Start');
  var buttonStop = document.getElementById('button-stop');
  var buttonReset = document.getElementById('button-rest');
  var Interval ;
}
  buttonStart.onclick = function() {
    
    clearInterval(Interval);
     Interval = setInterval(startTimer, 10);
  }
  
    buttonStop.onclick = function() {
       clearInterval(Interval);
  }
  

  buttonReset.onclick = function() {
     clearInterval(Interval);
    tens = "00";
  	seconds = "00";
    appendTens.innerHTML = tens;
  	appendSeconds.innerHTML = seconds;
  }
function startTimer () {
    tens++; 
    
    if(tens <= 9){
      appendTens.innerHTML = "0" + tens;
    }
    
    if (tens > 9){
      appendTens.innerHTML = tens;
      
    } 
    
    if (tens > 99) {
      console.log("seconds");
      seconds++;
      appendSeconds.innerHTML = "0" + seconds;
      tens = 0;
      appendTens.innerHTML = "0" + 0;
    }
    
    if (seconds > 9){
      appendSeconds.innerHTML = seconds;
    }
  
  }*/
  
