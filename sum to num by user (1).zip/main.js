console.log('Hello World!');
// store input numbers
/*const num1 = parseInt(prompt('Enter the first number '));
const num2 = parseInt(prompt('Enter the second number '));

//add two numbers
const sum = num1 + num2;

// display the sum
console.log(`The sum of ${num1} and ${num2} is ${sum}`);*/
// my js


// add function

function add(){
  //console.log('write way');
  // store input
  const num1 = parseInt(document.getElementById('first').value);

const num2 = parseInt( document.getElementById('second').value);

// add two numbers
const sum = num1 + num2;

// display the sum
 document.getElementById('demo').innerHTML = sum;
 
}
