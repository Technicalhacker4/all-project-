function snare(){
  var snare = new Audio('/sound/Snare-Drum-Hit-Level-1a-www.fesliyanstudios.com.mp3');
  snare.play();
}
function cymbal(){
  var cymbal = new Audio('/sound/Ride-Cymbal-Metal-Slide-Scrape-A-www.fesliyanstudios.com.mp3');
  cymbal.play();
}
function high(){
  var high = new Audio('/sound/Small-Tom-Drum-Hit-Level-1A-www.fesliyanstudios.com.mp3');
  high.play();
}
function bass (){
  var bass = new Audio('/sound/Bass-Drum-Hit-Level-2b-www.fesliyanstudios.com.mp3');
  bass.play();
}
function floor(){
  var floor = new Audio('/sound/Floor-Tom-Drum-Hit-Level-5B-www.fesliyanstudios.com.mp3');
  floor.play();
}
function middle (){
  var middle = new Audio('/sound/Ba-Bum-Tss-Joke-Drum-A2-www.fesliyanstudios.com.mp3');
  middle.play();
}
function hit() {
  var hit = new Audio('/sound/Crash-Cymbal-Hit-A-www.fesliyanstudios.com.mp3');
  hit.play();
}
