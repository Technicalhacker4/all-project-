console.log('Hello World!');
/*(function starttime(){
  var today = new Date();
   var h = today.getHours();
   var m = today.getMinutes();
  document.getElementsByid('time').innerText = h + ":" + m;
  var t = setTimeout(starttime , 500);
  m = checktime(m);
})();
function checktime(){
  if (i<10){
    i = 0;
    ++i;
  }
  return i;
}*/

var date = new Date();
var h = date.getHours();
var m = date.getMinutes();
var s = date.getSeconds();
document.getElementById('time').innerText= h + ":" + m + ":" + s;
