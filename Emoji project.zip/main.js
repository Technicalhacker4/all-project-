console.log('Hello World!');
for(var count = 0; count < 7; count++){
  switch(count){
    case 7: console.log('☺️ ☺ ☺ ☺ ☺ ☺ ☺ ');
    break;
    case 6: console.log('☺️ ☺ ☺ ☺ ☺ ☺ ');
    break;
    case 5: console.log('☺️ ☺ ☺ ☺ ☺');
    break;
    case 4: console.log('☺️ ☺ ☺ ☺ ');
    break;
    case 3: console.log('☺️ ☺ ☺ ');
    break;
    case 2: console.log('☺️ ☺️');
    break;
    case 1: console.log('☺️ ');
    break;
  }
}
/*for (var count = 0; count < 7; count++) {
    switch (count) {
        case 7:  console.log('AAAAAAA'); break;
        case 6:  console.log('AAAAAA'); break;
        case 5:  console.log('AAAAA'); break;
        case 4:  console.log('AAAA'); break;
        case 3:  console.log('AAA'); break;
        case 2:  console.log('AA'); break;
        case 1:  console.log('A'); break;
        case 0: console.log('xd'); break;
    }
}*/
for(var count = 0; count < 7; count++){
  switch(count){
    case 7: console.log('☺️ ☺ ☺ ☺ ☺ ☺ ☺ ');
    break;
    case 6: console.log('☺️ ☺ ☺ ☺ ☺ ☺ ');
    break;
    case 5: console.log('☺️ ☺ ☺ ☺ ☺');
    break;
    case 4: console.log('☺️ ☺ ☺ ☺ ');
    break;
    case 3: console.log('☺️ ☺ ☺ ');
    break;
    case 2: console.log('☺️ ☺️');
    break;
    case 1: console.log('☺️ ');
    break;
  }
}
for(var count = 0; count < 7; count++){
  switch(count){
    case 7: console.log('☺️ ☺ ☺ ☺ ☺ ☺ ☺ ');
    break;
    case 6: console.log('☺️ ☺ ☺ ☺ ☺ ☺ ');
    break;
    case 5: console.log('☺️ ☺ ☺ ☺ ☺');
    break;
    case 4: console.log('☺️ ☺ ☺ ☺ ');
    break;
    case 3: console.log('☺️ ☺ ☺ ');
    break;
    case 2: console.log('☺️ ☺️');
    break;
    case 1: console.log('☺️ ');
    break;
  }
}